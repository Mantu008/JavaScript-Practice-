const historyELement = document.querySelector('.history__data');
// get old data
const data = JSON.parse(localStorage.getItem('transactions')) || [];

const incomeData = data.filter((item) => item.type === 'Income');

function showIncomeData(incomeData) {
  if (incomeData.length === 0) {
    historyELement.innerHTML = `<img
                                class="recent__transactions__not__found__logo"
                                src="../assets/icons/not-found-error-alert-svgrepo-com.svg"
                                alt=""
                            />
                            <p>No transactions yet. Add your first one!</p>`;
  } else {
    console.log(data);
    historyELement.innerHTML = incomeData
      .map(
        (item) => `
        <div class="transaction__single__history">
                                ${
                                  item.type === 'Income'
                                    ? `
                                <img
                                    class="total__income__logo"
                                    src="../assets/icons/arrow-up-svgrepo-com.svg"
                                    alt=""
                                />`
                                    : `<img
                                    class="total__income__logo"
                                    src="../assets/icons/arrow-down-svgrepo-com.svg"
                                    alt=""
                                />`
                                }
                                <div class="transaction__mid">
                                    <p>${item.description}</p>
                                    <div class="transaction__mid__data">
                                        <p>${item.bank.split('__')[0]} ${!item.bank.split('__')[1] ? '' : item.bank.split('__')[1]}</p>
                                        <p>${item.category}</p>
                                        <p>${item.date.split(',')[0]}</p>
                                        <p>${item.date.split(',')[1]}</p>
                                    </div>
                                </div>
                                <b><p class="transaction__amount">₹${item.amount}</p></b>
                            </div>
    `,
      )
      .join('');
  }
}

showIncomeData(incomeData);

const incomeDataElement = document.querySelector('.income__record');
incomeDataElement.textContent = `${incomeData?.length} records found`;

let bankSelect = document.querySelector('.filter__right__select');

bankSelect.addEventListener('change', (e) => {
  if (e.target.value !== 'All__Bank') {
    let selectedBankName = e.target.value;
    let newIncomeData = incomeData.filter(
      (data) => data.bank === selectedBankName,
    );
    showIncomeData(newIncomeData);
    incomeDataElement.textContent = `${newIncomeData.length} records found`;
  } else {
    showIncomeData(incomeData);
    incomeDataElement.textContent = `${incomeData.length} records found`;
  }
});
